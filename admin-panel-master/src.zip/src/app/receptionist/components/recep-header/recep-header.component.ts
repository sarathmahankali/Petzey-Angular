import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recep-header',
  templateUrl: './recep-header.component.html',
  styleUrls: ['./recep-header.component.scss']
})
export class RecepHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
