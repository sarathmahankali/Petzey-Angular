import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recep-pets',
  templateUrl: './recep-pets.component.html',
  styleUrls: ['./recep-pets.component.scss']
})
export class RecepPetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
