import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recep-dashboard',
  templateUrl: './recep-dashboard.component.html',
  styleUrls: ['./recep-dashboard.component.scss']
})
export class RecepDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
