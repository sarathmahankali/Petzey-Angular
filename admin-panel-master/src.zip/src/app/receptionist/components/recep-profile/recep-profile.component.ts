import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recep-profile',
  templateUrl: './recep-profile.component.html',
  styleUrls: ['./recep-profile.component.scss']
})
export class RecepProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
