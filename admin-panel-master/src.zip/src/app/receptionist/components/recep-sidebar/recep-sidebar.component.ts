import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recep-sidebar',
  templateUrl: './recep-sidebar.component.html',
  styleUrls: ['./recep-sidebar.component.scss']
})
export class RecepSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
